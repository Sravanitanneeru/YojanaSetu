export type SocialCategory = 'SC' | 'ST' | 'OBC' | 'General' | 'Minority' | 'EWS';
export type Gender = 'Female' | 'Male' | 'Other';
export type AreaType = 'Rural' | 'Urban';
export type BusinessType = 
  | 'Artisan / Traditional Craft' 
  | 'Manufacturing' 
  | 'Food Processing' 
  | 'Service / Retail' 
  | 'Agriculture & Allied' 
  | 'Textiles & Handloom';

export type EducationLevel = 
  | 'Below 8th' 
  | '8th Pass' 
  | '10th Pass' 
  | '12th Pass' 
  | 'Graduate & Above';

export type LanguageCode = 'en' | 'hi' | 'te' | 'ta' | 'mr' | 'bn' | 'kn';

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  gender: Gender;
  category: SocialCategory;
  state: string;
  areaType: AreaType;
  businessType: BusinessType;
  tradeType?: string;
  education: EducationLevel;
  investmentNeeded: number; // in INR
  documentsHeld: string[];
  differentlyAbled: boolean;
  language: LanguageCode;
}

export type SchemeCategory = 
  | 'Loans & Credit'
  | 'Subsidies & Grants'
  | 'Artisans & Craftsmen'
  | 'Women Entrepreneurs'
  | 'SC/ST & Backward Classes'
  | 'Food & Agriculture'
  | 'Skill Training';

export interface SchemeRule {
  minAge?: number;
  maxAge?: number;
  allowedGenders?: Gender[];
  allowedCategories?: SocialCategory[];
  allowedAreaTypes?: AreaType[];
  allowedBusinessTypes?: BusinessType[];
  minInvestment?: number;
  maxInvestment?: number;
  minEducation?: EducationLevel;
  requiresArtisanTrade?: boolean;
  requiresSpecialGroup?: boolean; // SC, ST, Woman, Minority, PwD
}

export interface Scheme {
  id: string;
  code: string;
  name: string;
  nameInHindi?: string;
  ministry: string;
  level: 'Central' | 'State' | 'Central & State';
  category: SchemeCategory;
  tagline: string;
  maxAmount: number; // INR
  amountLabel: string;
  subsidyPercentage?: number;
  subsidyNote?: string;
  interestRate?: string;
  collateralRequired: boolean;
  briefDescription: string;
  eligibilityExplanation: string;
  targetBeneficiaries: string[];
  rules: SchemeRule;
  requiredDocuments: string[];
  keyBenefits: string[];
  applicationSteps: string[];
  officialPortalUrl: string;
  portalName: string;
  isActive: boolean;
  sdgGoals: number[];
}

export interface EligibilityResult {
  scheme: Scheme;
  isEligible: boolean;
  matchScore: number; // 0 - 100
  matchedReasons: string[];
  unmatchedReasons: string[];
  calculatedSubsidy?: number;
  calculatedSubsidyNote?: string;
  missingDocuments: string[];
  heldDocuments: string[];
}

export interface ApplicationTrackerItem {
  id: string;
  schemeId: string;
  schemeName: string;
  applicantName: string;
  appliedDate: string;
  requestedAmount: number;
  currentStage: 
    | 'Document Preparation' 
    | 'Portal Registration' 
    | 'Application Submitted' 
    | 'Department / DIC Verification' 
    | 'Bank Appraisal & Sanction' 
    | 'Subsidy / Loan Disbursed';
  stageProgress: number; // 0 to 100
  applicationRefNumber: string;
  bankName: string;
  branch: string;
  notes: string;
  reminders: {
    id: string;
    task: string;
    dueDate: string;
    completed: boolean;
    priority: 'High' | 'Medium' | 'Low';
  }[];
}
