import React, { useState } from 'react';
import { 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Building2, 
  Calendar, 
  Plus, 
  ChevronRight, 
  Download, 
  Share2, 
  ArrowUpRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import { ApplicationTrackerItem } from '../types';

interface ApplicationTrackerProps {
  applications: ApplicationTrackerItem[];
  setApplications: React.Dispatch<React.SetStateAction<ApplicationTrackerItem[]>>;
  onExploreSchemes: () => void;
}

const STAGES = [
  'Document Preparation',
  'Portal Registration',
  'Application Submitted',
  'Department / DIC Verification',
  'Bank Appraisal & Sanction',
  'Subsidy / Loan Disbursed'
] as const;

export const ApplicationTracker: React.FC<ApplicationTrackerProps> = ({
  applications,
  setApplications,
  onExploreSchemes,
}) => {
  const [selectedAppId, setSelectedAppId] = useState<string>(
    applications.length > 0 ? applications[0].id : ''
  );
  const [newTaskInput, setNewTaskInput] = useState<string>('');
  const [copiedNotice, setCopiedNotice] = useState<boolean>(false);

  const activeApp = applications.find((a) => a.id === selectedAppId) || applications[0];

  const handleToggleReminder = (appId: string, reminderId: string) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id !== appId) return app;
        return {
          ...app,
          reminders: app.reminders.map((rem) =>
            rem.id === reminderId ? { ...rem, completed: !rem.completed } : rem
          ),
        };
      })
    );
  };

  const handleAddReminder = (appId: string) => {
    if (!newTaskInput.trim()) return;
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id !== appId) return app;
        return {
          ...app,
          reminders: [
            ...app.reminders,
            {
              id: `rem-${Date.now()}`,
              task: newTaskInput.trim(),
              dueDate: 'In 5 days',
              completed: false,
              priority: 'High',
            },
          ],
        };
      })
    );
    setNewTaskInput('');
  };

  const handleAdvanceStage = (appId: string) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id !== appId) return app;
        const currentIndex = STAGES.indexOf(app.currentStage as any);
        if (currentIndex < STAGES.length - 1) {
          const nextStage = STAGES[currentIndex + 1];
          const newProgress = Math.round(((currentIndex + 2) / STAGES.length) * 100);
          return {
            ...app,
            currentStage: nextStage,
            stageProgress: newProgress,
          };
        }
        return app;
      })
    );
  };

  const handleCopyDossier = () => {
    if (!activeApp) return;
    const text = `YojanaSetu Application Dossier\nApplicant: ${activeApp.applicantName}\nScheme: ${activeApp.schemeName}\nRef No: ${activeApp.applicationRefNumber}\nStage: ${activeApp.currentStage} (${activeApp.stageProgress}%)\nBank: ${activeApp.bankName} - ${activeApp.branch}\nRequested Amount: ₹${activeApp.requestedAmount.toLocaleString('en-IN')}`;
    navigator.clipboard?.writeText(text);
    setCopiedNotice(true);
    setTimeout(() => setCopiedNotice(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Real-Time Tracking Header Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Active Applications</span>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {applications.length}
          </div>
          <span className="text-[11px] text-emerald-700 mt-0.5 block">Monitored in Real-Time</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Total Capital Tracked</span>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            ₹{applications.reduce((acc, a) => acc + a.requestedAmount, 0).toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Subsidies + Term Credits</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Pending Reminders</span>
          <div className="text-2xl font-bold font-mono text-blue-700 mt-1 tabular-nums">
            {applications.reduce(
              (acc, a) => acc + a.reminders.filter((r) => !r.completed).length,
              0
            )}
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Action items requiring attention</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">DIC & Bank Linkage</span>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            100%
          </div>
          <span className="text-[11px] text-emerald-700 mt-0.5 block">Government Gateway Connected</span>
        </div>
      </div>

      {applications.length === 0 ? (
        <div className="p-12 text-center bg-white border border-slate-200 rounded-2xl shadow-xs">
          <Clock className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-slate-900 mb-1">No Active Applications Being Tracked</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto mb-5">
            Use the Eligibility Engine to match schemes for your profile, then click "+ Track Application" to monitor stage progress and reminders.
          </p>
          <button
            onClick={onExploreSchemes}
            className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-xs"
          >
            Run Eligibility Assessment
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Application Switcher List */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                Tracked Applications
              </span>
              <button
                onClick={onExploreSchemes}
                className="text-xs font-semibold text-amber-700 hover:text-amber-800 cursor-pointer"
              >
                + Add Another
              </button>
            </div>

            {applications.map((app) => {
              const isSelected = (activeApp && activeApp.id === app.id);
              const pendingCount = app.reminders.filter((r) => !r.completed).length;

              return (
                <button
                  key={app.id}
                  onClick={() => setSelectedAppId(app.id)}
                  className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-amber-50/70 border-amber-600 shadow-xs'
                      : 'bg-white border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1 font-mono">
                    <span>{app.applicationRefNumber}</span>
                    <span className="font-bold text-amber-800 tabular-nums">{app.stageProgress}%</span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 truncate">
                    {app.schemeName}
                  </h4>

                  <div className="text-xs text-slate-600 mt-1 flex items-center justify-between">
                    <span>{app.applicantName}</span>
                    <span className="font-mono font-semibold tabular-nums text-slate-900">
                      ₹{app.requestedAmount.toLocaleString('en-IN')}
                    </span>
                  </div>

                  <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500 truncate max-w-[170px]">{app.currentStage}</span>
                    {pendingCount > 0 ? (
                      <span className="text-amber-800 font-semibold bg-amber-100/70 px-1.5 py-0.5 rounded">
                        {pendingCount} action(s)
                      </span>
                    ) : (
                      <span className="text-emerald-700 font-semibold">All tasks done</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: Active Application Deep-Dive Dashboard */}
          {activeApp && (
            <div className="lg:col-span-8 space-y-6">
              {/* Application Details Card */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-200">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                      <span className="font-mono font-semibold text-amber-800">{activeApp.applicationRefNumber}</span>
                      <span aria-hidden="true">·</span>
                      <span>Applied on {activeApp.appliedDate}</span>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900">
                      {activeApp.schemeName}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1">
                      Beneficiary: <strong>{activeApp.applicantName}</strong> · Requested Finance: <strong className="font-mono text-slate-900">₹{activeApp.requestedAmount.toLocaleString('en-IN')}</strong>
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={handleCopyDossier}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer border border-slate-200"
                    >
                      {copiedNotice ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <FileText className="w-3.5 h-3.5" />}
                      <span>{copiedNotice ? 'Dossier Copied!' : 'Export Summary'}</span>
                    </button>
                  </div>
                </div>

                {/* Interactive Multi-Stage Progress Stepper */}
                <div className="py-6 border-b border-slate-200">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                      Real-Time Lifecycle Stage: <span className="text-amber-800">{activeApp.currentStage}</span>
                    </span>
                    <span className="text-xs font-mono font-bold text-amber-700 tabular-nums">
                      {activeApp.stageProgress}% Completed
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-100 rounded-full h-2 mb-6 overflow-hidden">
                    <div
                      className="bg-amber-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${activeApp.stageProgress}%` }}
                    />
                  </div>

                  {/* 6 Stage Nodes */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                    {STAGES.map((stg, sIdx) => {
                      const curIdx = STAGES.indexOf(activeApp.currentStage as any);
                      const isPast = sIdx < curIdx;
                      const isCurrent = sIdx === curIdx;

                      return (
                        <div
                          key={stg}
                          className={`p-2.5 rounded-lg border text-xs text-center transition-colors ${
                            isCurrent
                              ? 'bg-amber-50 border-amber-600 font-bold text-amber-950'
                              : isPast
                              ? 'bg-emerald-50/50 border-emerald-300 text-emerald-900 font-medium'
                              : 'bg-slate-50 border-slate-200 text-slate-400'
                          }`}
                        >
                          <div className="text-[10px] font-mono mb-0.5">
                            {isPast ? '✓ STAGE ' + (sIdx + 1) : 'STAGE ' + (sIdx + 1)}
                          </div>
                          <div className="text-[11px] leading-tight line-clamp-2">{stg}</div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Advance Stage Button (Interactive simulation) */}
                  <div className="mt-4 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Simulate department verification / status advancement:</span>
                    <button
                      onClick={() => handleAdvanceStage(activeApp.id)}
                      className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold cursor-pointer transition-colors"
                    >
                      Advance to Next Stage →
                    </button>
                  </div>
                </div>

                {/* Assigned Institutional Desk */}
                <div className="py-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="font-bold text-slate-500 uppercase block mb-1">Nodal Bank Branch</span>
                    <p className="font-semibold text-slate-900">{activeApp.bankName}</p>
                    <p className="text-slate-500 text-[11px]">{activeApp.branch}</p>
                  </div>
                  <div>
                    <span className="font-bold text-slate-500 uppercase block mb-1">District Industry Desk (DIC)</span>
                    <p className="font-semibold text-slate-900">Taskforce Verification Cell</p>
                    <p className="text-slate-500 text-[11px]">Nodal Officer Contact: msme-district@gov.in</p>
                  </div>
                </div>

                {/* Action Reminders & Checklist */}
                <div className="pt-5">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                      Reminders & Document Actions ({activeApp.reminders.length})
                    </h4>
                    <span className="text-[11px] text-slate-500">
                      Tick off when completed
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    {activeApp.reminders.map((rem) => (
                      <div
                        key={rem.id}
                        onClick={() => handleToggleReminder(activeApp.id, rem.id)}
                        className={`flex items-start justify-between gap-3 p-3 rounded-lg border text-xs cursor-pointer transition-colors ${
                          rem.completed
                            ? 'bg-slate-50 border-slate-200 text-slate-400 line-through'
                            : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <div
                            className={`w-4 h-4 rounded mt-0.5 shrink-0 flex items-center justify-center border ${
                              rem.completed
                                ? 'bg-emerald-600 border-emerald-600 text-white'
                                : 'border-slate-300 bg-white'
                            }`}
                          >
                            {rem.completed && <Check className="w-3 h-3" />}
                          </div>
                          <span>{rem.task}</span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              rem.priority === 'High'
                                ? 'bg-red-50 text-red-700 border border-red-200'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {rem.priority}
                          </span>
                          <span className="text-[11px] text-slate-500 font-mono">{rem.dueDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add Custom Task */}
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Add a new reminder (e.g. Visit bank with machine quotation)..."
                      value={newTaskInput}
                      onChange={(e) => setNewTaskInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleAddReminder(activeApp.id);
                      }}
                      className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                    />
                    <button
                      onClick={() => handleAddReminder(activeApp.id)}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0"
                    >
                      Add Task
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
