import React, { useState } from 'react';
import { 
  BookOpen, 
  Workflow, 
  Coins, 
  CheckCircle2, 
  Target, 
  Sparkles,
  HelpCircle,
  Cpu
} from 'lucide-react';
import { SAMPLE_PROFILES } from '../data/sampleProfiles';

export const AbstractShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'abstract' | 'steps' | 'matrix' | 'benchmarks'>('abstract');

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-7 mb-6 border border-slate-800 shadow-sm">
        <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-2">
          <span>Project Abstract & System Explanation</span>
          <span aria-hidden="true">·</span>
          <span>Simple, Understandable Overview</span>
          <span aria-hidden="true">·</span>
          <span>UN SDGs 1, 8, 10</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
          YojanaSetu: How We Connect Small Entrepreneurs to Government Money
        </h2>
        <p className="text-slate-300 text-xs sm:text-sm mt-2 max-w-3xl leading-relaxed">
          Millions of artisans, women, and small business owners qualify for free government cash subsidies and collateral-free loans, but don't know how to apply. YojanaSetu makes this simple, transparent, and easy to track.
        </p>

        {/* Tab Buttons */}
        <div className="flex flex-wrap gap-2 mt-5 pt-5 border-t border-slate-800">
          <button
            onClick={() => setActiveTab('abstract')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'abstract' ? 'bg-amber-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            The Abstract & Core Problem
          </button>
          <button
            onClick={() => setActiveTab('steps')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'steps' ? 'bg-amber-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            How YojanaSetu Works (Step-by-Step)
          </button>
          <button
            onClick={() => setActiveTab('matrix')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'matrix' ? 'bg-amber-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Medium-Range Categories & Amounts
          </button>
          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'benchmarks' ? 'bg-amber-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Example Profiles Tested
          </button>
        </div>
      </div>

      {/* Tab 1: Abstract & Problem */}
      {activeTab === 'abstract' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
            <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-amber-600" />
              <span>The Abstract in Plain Words</span>
            </h3>
            <p className="text-slate-700 text-xs sm:text-sm leading-relaxed">
              Governments run many schemes for loans, subsidies, skill training and entrepreneurship aimed at marginalized communities, yet a large number of eligible people never apply. They do not know which schemes fit their situation, find the eligibility rules hard to understand, and get stuck on paperwork and application steps.
            </p>
            <p className="text-slate-700 text-xs sm:text-sm leading-relaxed">
              This project proposes <strong>YojanaSetu</strong>, an AI platform that matches an entrepreneur's profile with the schemes they qualify for and guides them through each step. The user answers a short conversational questionnaire by text or voice in their own language, covering category, state, age, gender, business type, investment needed and documents already held.
            </p>
            <p className="text-slate-700 text-xs sm:text-sm leading-relaxed">
              A structured knowledge base built from official central and state guidelines is combined with a rule-based eligibility engine and a retrieval-augmented language model. The platform returns a ranked list of suitable schemes with benefits, a plain explanation of eligibility, a document checklist, application steps and official links, and it also explains why a scheme was not matched. A checklist tracker with reminders helps users finish their applications, and an admin panel allows officers to keep scheme data up to date.
            </p>
          </div>

          {/* 3 Real Life Barriers */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl text-xs space-y-1">
              <span className="font-bold text-amber-900 uppercase">Barrier 1</span>
              <h4 className="font-bold text-slate-900 text-sm">Complicated Rules</h4>
              <p className="text-slate-600">
                Government documents use difficult legal terminology. Most rural artisans cannot tell if their craft or caste qualifies.
              </p>
            </div>

            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl text-xs space-y-1">
              <span className="font-bold text-amber-900 uppercase">Barrier 2</span>
              <h4 className="font-bold text-slate-900 text-sm">Missing Middle Range</h4>
              <p className="text-slate-600">
                Entrepreneurs needing ₹1 Lakh to ₹10 Lakhs often borrow from moneylenders at 24% interest because they don't know banks offer 5% loans.
              </p>
            </div>

            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl text-xs space-y-1">
              <span className="font-bold text-amber-900 uppercase">Barrier 3</span>
              <h4 className="font-bold text-slate-900 text-sm">Paperwork Confusion</h4>
              <p className="text-slate-600">
                Applicants get rejected without knowing why, or drop out because they don't know which certificates are required.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Step-by-Step Working */}
      {activeTab === 'steps' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-5">
          <h3 className="text-base sm:text-lg font-bold text-slate-900">
            How YojanaSetu Works from Start to Finish
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-6 h-6 rounded-full bg-amber-600 text-white font-bold flex items-center justify-center font-mono text-xs">1</span>
                <h4 className="text-sm font-bold text-slate-900">Voice or Simple Questionnaire</h4>
              </div>
              <p className="text-slate-600">
                The entrepreneur speaks or answers 4 simple questions in their own language (Hindi, Telugu, Tamil, etc.) regarding their craft, caste, age, and required amount.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-6 h-6 rounded-full bg-amber-600 text-white font-bold flex items-center justify-center font-mono text-xs">2</span>
                <h4 className="text-sm font-bold text-slate-900">Smart Eligibility Engine</h4>
              </div>
              <p className="text-slate-600">
                Our rule engine checks official government rules to verify exact eligibility (age, craft category, rural bonus) with 100% precision.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-6 h-6 rounded-full bg-amber-600 text-white font-bold flex items-center justify-center font-mono text-xs">3</span>
                <h4 className="text-sm font-bold text-slate-900">Clear Subsidy & Benefits</h4>
              </div>
              <p className="text-slate-600">
                Shows exact free cash subsidies (e.g. 35% margin grant), bank loan at low interest (4-5%), and toolkit vouchers with zero property mortgage.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-6 h-6 rounded-full bg-amber-600 text-white font-bold flex items-center justify-center font-mono text-xs">4</span>
                <h4 className="text-sm font-bold text-slate-900">Live Application Tracking</h4>
              </div>
              <p className="text-slate-600">
                Tracks each stage (documents, portal submission, bank review, money disbursed) with helpful reminders so you never miss a step.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Medium-Range Categories & Amounts Matrix */}
      {activeTab === 'matrix' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="mb-2">
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              Medium-Range Assistance: What Real Entrepreneurs Need
            </h3>
            <p className="text-xs text-slate-500">
              Clear breakdown of schemes for everyday micro and small enterprises (₹50,000 to ₹10 Lakhs):
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-800 font-bold">
                  <th className="py-2.5 px-3">Scheme</th>
                  <th className="py-2.5 px-3">Best For</th>
                  <th className="py-2.5 px-3">Money Range</th>
                  <th className="py-2.5 px-3">Free Subsidy</th>
                  <th className="py-2.5 px-3">Interest / Guarantee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-bold text-slate-900">PM Vishwakarma</td>
                  <td className="py-2.5 px-3">18 Artisan Crafts (Potters, Weavers, Carpenters, Tailors)</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-800">Up to ₹3,00,000</td>
                  <td className="py-2.5 px-3 font-semibold text-emerald-700">₹15,000 Free Toolkit Kit</td>
                  <td className="py-2.5 px-3">Only 5% Interest · No Collateral</td>
                </tr>

                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-bold text-slate-900">PMEGP Scheme</td>
                  <td className="py-2.5 px-3">Small Manufacturing, Food Units & Services</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-800">₹2 Lakhs to ₹20 Lakhs</td>
                  <td className="py-2.5 px-3 font-bold text-emerald-700">Up to 35% Cash Subsidy</td>
                  <td className="py-2.5 px-3">Bank Loan · No Property Pledge</td>
                </tr>

                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-bold text-slate-900">Mudra Kishor & Tarun</td>
                  <td className="py-2.5 px-3">Tailoring shops, grocery, repair centers, machinery</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-800">₹50,000 to ₹10 Lakhs</td>
                  <td className="py-2.5 px-3 text-slate-500">Zero Processing Fee</td>
                  <td className="py-2.5 px-3">Priority MSME Rate · No Collateral</td>
                </tr>

                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-bold text-slate-900">PMFME Food Processing</td>
                  <td className="py-2.5 px-3">Spices, pickles, millets, flour mills, snacks</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-800">₹1 Lakh to ₹15 Lakhs</td>
                  <td className="py-2.5 px-3 font-bold text-emerald-700">35% Free Capital Grant</td>
                  <td className="py-2.5 px-3">Standard Bank Rate · Training Free</td>
                </tr>

                <tr className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-bold text-slate-900">Mahila Samridhi</td>
                  <td className="py-2.5 px-3">Women entrepreneurs from backward classes (OBC)</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-800">Up to ₹1,40,000</td>
                  <td className="py-2.5 px-3 font-semibold text-emerald-700">Ultra-low 4% Interest</td>
                  <td className="py-2.5 px-3">Micro-credit · 95% Financed</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Example Profiles Tested */}
      {activeTab === 'benchmarks' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
          <h3 className="text-base sm:text-lg font-bold text-slate-900">
            Real Scenarios Tested in YojanaSetu
          </h3>
          <div className="space-y-3">
            {SAMPLE_PROFILES.map((p, idx) => (
              <div key={p.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-900">
                    {idx + 1}. {p.title}
                  </span>
                  <span className="font-mono text-amber-800 font-bold">
                    Capital: ₹{(p.investmentNeeded / 100000).toFixed(1)} Lakhs
                  </span>
                </div>
                <p className="text-slate-600 mb-2">{p.story}</p>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="font-semibold text-slate-700">Top Matched Schemes:</span>
                  {p.expectedBestMatches.map((schemeName) => (
                    <span key={schemeName} className="bg-white border border-slate-300 text-slate-800 px-2 py-0.5 rounded font-medium">
                      ✓ {schemeName}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
