import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Plus, 
  CheckCircle, 
  Edit3, 
  Trash2, 
  Users, 
  Landmark, 
  TrendingUp, 
  FileCheck2,
  RefreshCw
} from 'lucide-react';
import { Scheme, SchemeCategory } from '../types';

interface AdminPanelProps {
  schemes: Scheme[];
  setSchemes: React.Dispatch<React.SetStateAction<Scheme[]>>;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  schemes,
  setSchemes,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingSchemeId, setEditingSchemeId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string>('');

  // New Scheme Form State
  const [newScheme, setNewScheme] = useState<Partial<Scheme>>({
    code: '',
    name: '',
    ministry: '',
    level: 'Central',
    category: 'Loans & Credit',
    tagline: '',
    maxAmount: 500000,
    amountLabel: 'Up to ₹5,00,000',
    subsidyPercentage: 25,
    subsidyNote: '',
    collateralRequired: false,
    briefDescription: '',
    eligibilityExplanation: '',
    requiredDocuments: ['Aadhaar Card', 'Bank Passbook', 'PAN Card'],
    applicationSteps: [
      'Step 1: Online registration at departmental portal',
      'Step 2: Scrutiny by District Industries Centre (DIC)',
      'Step 3: Bank branch loan sanction'
    ],
    officialPortalUrl: 'https://msme.gov.in',
    portalName: 'National MSME Portal',
    isActive: true,
  });

  const handleToggleActive = (id: string) => {
    setSchemes((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s))
    );
    setNotice('Scheme status updated successfully.');
    setTimeout(() => setNotice(''), 3000);
  };

  const handleCreateScheme = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newScheme.name || !newScheme.code) return;

    const fullScheme: Scheme = {
      id: `scheme-${Date.now()}`,
      code: newScheme.code || 'GOV-NEW',
      name: newScheme.name || '',
      ministry: newScheme.ministry || 'State Directorate of Industries',
      level: newScheme.level || 'Central & State',
      category: newScheme.category || 'Subsidies & Grants',
      tagline: newScheme.tagline || 'Special enterprise development financial assistance',
      maxAmount: Number(newScheme.maxAmount) || 500000,
      amountLabel: newScheme.amountLabel || `Up to ₹${Number(newScheme.maxAmount).toLocaleString('en-IN')}`,
      subsidyPercentage: Number(newScheme.subsidyPercentage) || 0,
      subsidyNote: newScheme.subsidyNote || 'Standard government subvention',
      collateralRequired: !!newScheme.collateralRequired,
      briefDescription: newScheme.briefDescription || 'Newly added official welfare scheme.',
      eligibilityExplanation: newScheme.eligibilityExplanation || 'Open to qualified micro-entrepreneurs as per state notifications.',
      targetBeneficiaries: ['Marginalized Entrepreneurs', 'Women Self-Help Groups'],
      rules: {
        minAge: 18,
        maxInvestment: Number(newScheme.maxAmount) || 500000,
      },
      requiredDocuments: newScheme.requiredDocuments || ['Aadhaar Card', 'Bank Passbook'],
      keyBenefits: ['Credit assistance', 'Direct subsidy credit'],
      applicationSteps: newScheme.applicationSteps || ['Step 1: Departmental submission'],
      officialPortalUrl: newScheme.officialPortalUrl || 'https://msme.gov.in',
      portalName: newScheme.portalName || 'Government Portal',
      isActive: true,
      sdgGoals: [1, 8],
    };

    setSchemes((prev) => [fullScheme, ...prev]);
    setShowAddForm(false);
    setNotice(`Scheme "${fullScheme.name}" added to knowledge base.`);
    setTimeout(() => setNotice(''), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Officer Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-800 mb-1">
            <span>District Industries Centre (DIC) & Ministry Officer Console</span>
            <span aria-hidden="true">·</span>
            <span>Policy Governance Mode</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Scheme Data Management & Demographic Oversight
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Maintain scheme eligibility thresholds, publish new central or state gazettes, and monitor real-time applicant inclusion metrics.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{showAddForm ? 'Close Form' : 'Publish New Scheme'}</span>
        </button>
      </div>

      {notice && (
        <div className="mb-6 p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-lg text-xs font-semibold flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          <span>{notice}</span>
        </div>
      )}

      {/* Demographic Real-Time Telemetry Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
            Caste Diversity Ratio
          </span>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            64% SC / ST / OBC
          </div>
          <span className="text-[11px] text-emerald-700 mt-0.5 block">Affirmative quotas satisfied</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
            Women Beneficiary Share
          </span>
          <div className="text-xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            46.2%
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Exceeds 33% national mandate</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
            Rural Penetration
          </span>
          <div className="text-xl font-bold font-mono text-blue-700 mt-1 tabular-nums">
            71.8%
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Tier 2/3 and Gram Panchayat clusters</span>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
            Active Schemes In Base
          </span>
          <div className="text-xl font-bold font-mono text-purple-700 mt-1 tabular-nums">
            {schemes.filter((s) => s.isActive).length} Active / {schemes.length} Total
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">Live in matching engine</span>
        </div>
      </div>

      {/* Publish New Scheme Modal / Accordion */}
      {showAddForm && (
        <form onSubmit={handleCreateScheme} className="bg-white border border-slate-300 rounded-2xl p-6 shadow-sm mb-8 space-y-4">
          <h3 className="text-base font-bold text-slate-900 pb-2 border-b border-slate-200">
            Publish New Central or State Scheme to Knowledge Base
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Scheme Code</label>
              <input
                type="text"
                required
                placeholder="e.g. UP-ODOP-2026"
                value={newScheme.code}
                onChange={(e) => setNewScheme({ ...newScheme, code: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono bg-white"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Scheme Official Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Mukhyamantri Yuva Swarojgar Yojana"
                value={newScheme.name}
                onChange={(e) => setNewScheme({ ...newScheme, name: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Nodal Ministry / Department</label>
              <input
                type="text"
                required
                placeholder="e.g. Department of MSME & Export Promotion"
                value={newScheme.ministry}
                onChange={(e) => setNewScheme({ ...newScheme, ministry: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Category</label>
              <select
                value={newScheme.category}
                onChange={(e) => setNewScheme({ ...newScheme, category: e.target.value as SchemeCategory })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="Loans & Credit">Loans & Credit</option>
                <option value="Subsidies & Grants">Subsidies & Grants</option>
                <option value="Artisans & Craftsmen">Artisans & Craftsmen</option>
                <option value="Women Entrepreneurs">Women Entrepreneurs</option>
                <option value="SC/ST & Backward Classes">SC/ST & Backward Classes</option>
                <option value="Food & Agriculture">Food & Agriculture</option>
                <option value="Skill Training">Skill Training</option>
              </select>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Max Ceiling Amount (₹)</label>
              <input
                type="number"
                value={newScheme.maxAmount}
                onChange={(e) => setNewScheme({ ...newScheme, maxAmount: parseInt(e.target.value, 10) || 0 })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono bg-white"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Subsidy Percentage (%)</label>
              <input
                type="number"
                value={newScheme.subsidyPercentage}
                onChange={(e) => setNewScheme({ ...newScheme, subsidyPercentage: parseInt(e.target.value, 10) || 0 })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono bg-white"
              />
            </div>
          </div>

          <div className="text-xs">
            <label className="font-bold text-slate-700 block mb-1">Brief Description / Eligibility Rules</label>
            <textarea
              rows={2}
              value={newScheme.briefDescription}
              onChange={(e) => setNewScheme({ ...newScheme, briefDescription: e.target.value })}
              placeholder="State key criteria, target age, margin money subsidy rules, and priority beneficiaries..."
              className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs"
            >
              Publish Scheme
            </button>
          </div>
        </form>
      )}

      {/* Schemes Master Data Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
            Master Scheme Repository ({schemes.length})
          </span>
          <span className="text-xs text-slate-500">Live Knowledge Base Sync</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-semibold">
                <th className="py-2.5 px-3">Code</th>
                <th className="py-2.5 px-3">Scheme Name</th>
                <th className="py-2.5 px-3">Ministry</th>
                <th className="py-2.5 px-3">Max Amount</th>
                <th className="py-2.5 px-3">Subsidy</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {schemes.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50/80">
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-800">{s.code}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900 max-w-xs truncate">{s.name}</td>
                  <td className="py-2.5 px-3 text-slate-500 max-w-xs truncate">{s.ministry}</td>
                  <td className="py-2.5 px-3 font-mono tabular-nums">{s.amountLabel}</td>
                  <td className="py-2.5 px-3 font-bold text-amber-700">{s.subsidyPercentage ? `${s.subsidyPercentage}%` : 'Concessional'}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        s.isActive ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {s.isActive ? 'Active' : 'Archived'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => handleToggleActive(s.id)}
                      className="text-xs text-slate-600 hover:text-amber-800 font-medium cursor-pointer underline"
                    >
                      {s.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
