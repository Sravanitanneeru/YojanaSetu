import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  X, 
  Volume2, 
  VolumeX, 
  Bot, 
  User, 
  HelpCircle,
  Loader2
} from 'lucide-react';
import { UserProfile, LanguageCode, Scheme } from '../types';
import { speakText, stopSpeaking } from '../utils/speech';
import { SUPPORTED_LANGUAGES } from '../utils/translations';

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  matchedSchemes: Scheme[];
  language: LanguageCode;
  initialQuestion?: string;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  time: string;
}

const SAMPLE_QUESTIONS: Record<LanguageCode, string[]> = {
  en: [
    'How do I get an Udyam certificate without paying any fee?',
    'Can I apply for both PMEGP and PM Vishwakarma together?',
    'What is the difference between Mudra Shishu and Mudra Kishor?',
    'Why is a caste certificate required for the 35% PMEGP subsidy?',
  ],
  hi: [
    'बिना किसी शुल्क के उद्यम प्रमाणपत्र (Udyam) कैसे प्राप्त करें?',
    'क्या मैं PMEGP और पीएम विश्वकर्मा दोनों में एक साथ आवेदन कर सकता हूँ?',
    'मुद्रा शिशु और मुद्रा किशोर में क्या मुख्य अंतर है?',
    'PMEGP में 35% ग्रामीण सब्सिडी के लिए कौन से दस्तावेज जरूरी हैं?',
  ],
  te: [
    'ఉచితంగా ఉద్యామ్ రిజిస్ట్రేషన్ సర్టిఫికేట్ ఎలా పొందాలి?',
    'PMEGP మరియు పిఎం విశ్వకర్మ రెండింటికీ దరఖాస్తు చేసుకోవచ్చా?',
    'ముద్రా శిశు మరియు కిషోర్ లోన్ల మధ్య తేడా ఏమిటి?',
    '35% సబ్సిడీ పొందడానికి ఏ పత్రాలు అవసరం?',
  ],
  ta: [
    'உத்யம் சான்றிதழை இலவசமாக பெறுவது எப்படி?',
    'PMEGP மற்றும் PM விஸ்வகர்மா இரண்டிற்கும் ஒன்றாக விண்ணப்பிக்கலாமா?',
    'முத்ரா சிசு மற்றும் கிஷோருக்கு என்ன வித்தியாசம்?',
    '35% மானியம் பெற தேவையான ஆவணங்கள் என்ன?',
  ],
  mr: [
    'विनामूल्य उद्यम प्रमाणपत्र कसे मिळवावे?',
    'मी PMEGP आणि पीएम विश्वकर्मा दोन्हीसाठी अर्ज करू शकतो का?',
    'मुद्रा शिशु आणि किशोर कर्जामध्ये काय फरक आहे?',
    '३५% सबसिडी मिळविण्यासाठी कोणती कागदपत्रे लागतात?',
  ],
  bn: [
    'বিনা খরচে উদ্যম সার্টিফিকেট কীভাবে পাবেন?',
    'আমি কি PMEGP এবং পিএম বিশ্বকর্মা উভয়টিতে আবেদন করতে পারি?',
    'মুদ্রা শিশু এবং কিশোরের মধ্যে পার্থক্য কী?',
    '৩৫% ভরতুকি পাওয়ার জন্য কী কী নথিপত্র প্রয়োজন?',
  ],
  kn: [
    'ಯಾವುದೇ ಶುಲ್ಕವಿಲ್ಲದೆ ಉದ್ಯಮ್ ಪ್ರಮಾಣಪತ್ರ ಪಡೆಯುವುದು ಹೇಗೆ?',
    'ನಾನು PMEGP ಮತ್ತು ಪಿಎಂ ವಿಶ್ವಕರ್ಮ ಎರಡಕ್ಕೂ ಅರ್ಜಿ ಸಲ್ಲಿಸಬಹುದೇ?',
    'ಮುದ್ರಾ ಶಿಶು ಮತ್ತು ಕಿಶೋರ್ ನಡುವಿನ ವ್ಯತ್ಯಾಸವೇನು?',
    '35% ಸಬ್ಸಿಡಿಗೆ ಅಗತ್ಯವಿರುವ ದಾಖಲೆಗಳು ಯಾವುವು?',
  ],
};

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({
  isOpen,
  onClose,
  userProfile,
  matchedSchemes,
  language,
  initialQuestion,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: language === 'hi'
        ? `नमस्ते ${userProfile.name}! मैं आपका योजनासेतु AI सहायक हूँ। आप केंद्र या राज्य सरकार की किसी भी ऋण, सब्सिडी या कौशल योजना के बारे में मुझसे अपनी भाषा में पूछ सकते हैं।`
        : `Hello ${userProfile.name}! I am your YojanaSetu AI advisor. Ask me anything about subsidies, application documents, or eligibility rules in your language.`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputPrompt, setInputPrompt] = useState<string>(initialQuestion || '');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];
  const sampleQs = SAMPLE_QUESTIONS[language] || SAMPLE_QUESTIONS.en;

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputPrompt;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: textToSend.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          language: currentLangObj.label,
          userProfile,
          matchedSchemes: matchedSchemes.map((s) => ({
            name: s.name,
            code: s.code,
            amount: s.amountLabel,
            subsidy: s.subsidyNote,
          })),
        }),
      });

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: data.reply || 'Information retrieved.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error(err);
      const fallbackMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: `Under PMEGP and PM Vishwakarma guidelines, eligible marginalized entrepreneurs receive up to 35% capital subsidy and collateral-free credit at 5%. You can apply directly through the official KVIC or PM Vishwakarma portal at no charge.`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReadMessage = (text: string) => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }
    setIsSpeaking(true);
    speakText(text, currentLangObj.speechLocale, () => {
      setIsSpeaking(false);
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl border-l border-slate-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600 flex items-center justify-center text-white font-bold text-sm">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">YojanaSetu AI Advisor</h3>
              <p className="text-[11px] text-slate-300">
                Responding in {currentLangObj.nativeLabel} ({currentLangObj.label})
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="text-slate-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Suggested Quick Questions */}
        <div className="p-3 bg-slate-50 border-b border-slate-200">
          <span className="text-[11px] font-bold text-slate-600 uppercase block mb-1.5">
            Suggested Inquiries:
          </span>
          <div className="flex flex-col gap-1.5">
            {sampleQs.slice(0, 3).map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="text-left text-xs p-1.5 rounded bg-white hover:bg-amber-50 text-slate-700 hover:text-amber-900 border border-slate-200 transition-colors cursor-pointer"
              >
                💡 {q}
              </button>
            ))}
          </div>
        </div>

        {/* Chat History Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3 leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-amber-600 text-white rounded-br-xs'
                    : 'bg-slate-100 text-slate-900 rounded-bl-xs border border-slate-200'
                }`}
              >
                <p className="whitespace-pre-wrap">{m.text}</p>
                {m.sender === 'assistant' && (
                  <div className="mt-2 pt-1 border-t border-slate-200 flex items-center justify-between">
                    <button
                      onClick={() => handleReadMessage(m.text)}
                      className="text-[11px] font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Listen</span>
                    </button>
                    <span className="text-[10px] text-slate-400">{m.time}</span>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs p-2">
              <Loader2 className="w-4 h-4 animate-spin text-amber-600" />
              <span>Analyzing government rules and guidelines...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-slate-200 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder={`Ask in ${currentLangObj.nativeLabel}...`}
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              className="flex-1 px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
            />
            <button
              type="submit"
              disabled={isLoading || !inputPrompt.trim()}
              className="p-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white rounded-xl cursor-pointer transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
