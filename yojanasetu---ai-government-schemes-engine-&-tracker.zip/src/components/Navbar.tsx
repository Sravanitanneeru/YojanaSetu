import React from 'react';
import { ShieldCheck, MessageSquareText, Globe } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../utils/translations';
import { LanguageCode } from '../types';

interface NavbarProps {
  currentTab: 'assessment' | 'directory' | 'tracker' | 'abstract' | 'admin';
  setCurrentTab: (tab: 'assessment' | 'directory' | 'tracker' | 'abstract' | 'admin') => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  onOpenAiAssistant: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  language,
  setLanguage,
  onOpenAiAssistant,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => setCurrentTab('assessment')}
          className="flex items-center gap-2.5 text-left focus:outline-none group"
        >
          <div className="w-9 h-9 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-lg shadow-xs group-hover:bg-amber-700 transition-colors">
            य
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap leading-tight">
              YojanaSetu
            </span>
            <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap">
              योजनासेतु · Inclusive Scheme Bridge
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (Single-line, unboxed hover style) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setCurrentTab('assessment')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 border-b-2 ${
              currentTab === 'assessment'
                ? 'border-amber-600 text-amber-700 font-semibold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Eligibility Engine
          </button>
          <button
            onClick={() => setCurrentTab('directory')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 border-b-2 ${
              currentTab === 'directory'
                ? 'border-amber-600 text-amber-700 font-semibold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Scheme Catalog
          </button>
          <button
            onClick={() => setCurrentTab('tracker')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 border-b-2 ${
              currentTab === 'tracker'
                ? 'border-amber-600 text-amber-700 font-semibold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Application Tracker
          </button>
          <button
            onClick={() => setCurrentTab('abstract')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 border-b-2 ${
              currentTab === 'abstract'
                ? 'border-amber-600 text-amber-700 font-semibold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Abstract & Architecture
          </button>
          <button
            onClick={() => setCurrentTab('admin')}
            className={`whitespace-nowrap transition-colors cursor-pointer py-1 border-b-2 ${
              currentTab === 'admin'
                ? 'border-amber-600 text-amber-700 font-semibold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Officer Portal
          </button>
        </nav>

        {/* Zone 3: Primary Actions (Language Selector & AI Advisor) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Switcher */}
          <div className="relative flex items-center bg-slate-100 rounded-lg p-1 border border-slate-200">
            <Globe className="w-4 h-4 text-slate-500 ml-1.5 mr-1" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="bg-transparent text-xs font-semibold text-slate-700 focus:outline-none pr-1.5 cursor-pointer py-1"
              aria-label="Select Interface Language"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.nativeLabel} ({lang.label})
                </option>
              ))}
            </select>
          </div>

          {/* AI Advisor Button */}
          <button
            onClick={onOpenAiAssistant}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer shadow-xs"
          >
            <MessageSquareText className="w-3.5 h-3.5 text-amber-400" />
            <span>AI Advisor</span>
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="flex lg:hidden overflow-x-auto px-4 py-2 border-t border-slate-100 bg-slate-50 gap-4 text-xs font-medium text-slate-600 no-scrollbar">
        <button
          onClick={() => setCurrentTab('assessment')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            currentTab === 'assessment' ? 'text-amber-700 font-bold border-b border-amber-600' : ''
          }`}
        >
          Eligibility Engine
        </button>
        <button
          onClick={() => setCurrentTab('directory')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            currentTab === 'directory' ? 'text-amber-700 font-bold border-b border-amber-600' : ''
          }`}
        >
          Scheme Catalog
        </button>
        <button
          onClick={() => setCurrentTab('tracker')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            currentTab === 'tracker' ? 'text-amber-700 font-bold border-b border-amber-600' : ''
          }`}
        >
          Application Tracker
        </button>
        <button
          onClick={() => setCurrentTab('abstract')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            currentTab === 'abstract' ? 'text-amber-700 font-bold border-b border-amber-600' : ''
          }`}
        >
          Abstract & Architecture
        </button>
        <button
          onClick={() => setCurrentTab('admin')}
          className={`whitespace-nowrap shrink-0 py-1 ${
            currentTab === 'admin' ? 'text-amber-700 font-bold border-b border-amber-600' : ''
          }`}
        >
          Officer Portal
        </button>
      </div>
    </header>
  );
};
