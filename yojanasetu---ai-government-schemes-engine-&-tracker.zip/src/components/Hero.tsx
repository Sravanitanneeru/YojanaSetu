import React from 'react';
import { ArrowRight, CheckCircle2, Coins, ShieldCheck, HeartHandshake, Sparkles } from 'lucide-react';
import { SAMPLE_PROFILES } from '../data/sampleProfiles';
import { UserProfile, LanguageCode } from '../types';
import { UI_TRANSLATIONS } from '../utils/translations';

interface HeroProps {
  language: LanguageCode;
  onStartAssessment: () => void;
  onSelectSampleProfile: (profile: UserProfile) => void;
  onExploreDirectory: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  language,
  onStartAssessment,
  onSelectSampleProfile,
  onExploreDirectory,
}) => {
  const t = UI_TRANSLATIONS[language] || UI_TRANSLATIONS.en;

  return (
    <section className="relative overflow-hidden bg-white border-b border-slate-200 pt-7 pb-10 sm:pt-10 sm:pb-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Two-column Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          {/* Left Column: Human, Friendly, Understandable Message */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Friendly Kicker */}
            <div className="flex items-center gap-2 text-xs font-bold text-amber-800 tracking-wide mb-2.5">
              <span>Official Government Welfare Bridge</span>
              <span aria-hidden="true">·</span>
              <span>Zero Intermediary Fees</span>
              <span aria-hidden="true">·</span>
              <span>All Indian States</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight leading-snug text-balance mb-3.5">
              Find Government Loans & Cash Subsidies Made for Your Small Business
            </h1>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl mb-5">
              Are you an artisan, shopkeeper, woman entrepreneur, or starting a small trade? Discover schemes tailored to your exact situation in simple words. Get up to <strong className="text-slate-900">35% free government grant (subsidy)</strong> and <strong className="text-slate-900">collateral-free loans</strong> with no land or house mortgage.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <button
                onClick={onStartAssessment}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-lg shadow-xs transition-colors text-xs sm:text-sm cursor-pointer"
              >
                <span>{t.startAssessment}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreDirectory}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg transition-colors text-xs sm:text-sm cursor-pointer border border-slate-200"
              >
                <span>{t.exploreDirectory}</span>
              </button>
            </div>

            {/* Quick 1-Click Example Personas (Easy to Understand) */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700">
                  Try An Example with 1-Click (Medium Range Scenarios):
                </span>
                <span className="text-[11px] text-slate-500">Instant test</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {SAMPLE_PROFILES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => onSelectSampleProfile(p)}
                    className="text-xs px-2.5 py-1.5 bg-white border border-slate-300 hover:border-amber-500 hover:text-amber-800 rounded-md font-medium text-slate-700 transition-colors shadow-2xs text-left cursor-pointer"
                  >
                    <span className="font-semibold text-slate-900">{p.name.split(' ')[0]}</span>
                    <span className="text-slate-500 text-[11px]"> · {p.tradeType || p.businessType.split('/')[0]} (₹{(p.investmentNeeded / 100000).toFixed(1)}L)</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual with Real Indian Artisan / Enterprise */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-slate-100">
              <img
                src="/src/assets/images/hero_entrepreneur_artisan_1791697405169.jpg"
                alt="Empowered Indian artisan woman in her textile workshop"
                className="w-full h-72 sm:h-80 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/25 to-transparent flex flex-col justify-end p-4 sm:p-5 text-white">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300 mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Real Beneficiary Support</span>
                </div>
                <h2 className="text-sm sm:text-base font-bold text-white leading-snug">
                  Potters, Tailors, Weavers, Food Makers & Small Vendors
                </h2>
                <p className="text-[11px] text-slate-200 mt-0.5">
                  Understand your rights, calculate your cash subsidy, and apply on official portals with zero confusion.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Clear Medium-Range Highlights */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mt-8 pt-6 border-t border-slate-200">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <div className="text-xs font-bold text-amber-700 font-mono">₹50K to ₹10 Lakhs</div>
            <div className="text-xs font-bold text-slate-900 mt-0.5">Medium-Range Funding</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Perfect for small shops, machines & tools</div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <div className="text-xs font-bold text-emerald-700 font-mono">Up to 35% Subsidy</div>
            <div className="text-xs font-bold text-slate-900 mt-0.5">Free Government Cash</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Non-refundable money paid to your loan</div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <div className="text-xs font-bold text-blue-700 font-mono">Zero Collateral</div>
            <div className="text-xs font-bold text-slate-900 mt-0.5">No Property Mortgaged</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Backed by Government guarantee fund</div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <div className="text-xs font-bold text-purple-700 font-mono">7 Local Languages</div>
            <div className="text-xs font-bold text-slate-900 mt-0.5">Voice & Text Help</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Hindi, Telugu, Tamil, Marathi, Bengali, Kannada</div>
          </div>
        </div>
      </div>
    </section>
  );
};
