import React, { useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  ArrowUpRight, 
  ExternalLink, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  Volume2, 
  VolumeX,
  Coins,
  ShieldCheck,
  Check,
  Info
} from 'lucide-react';
import { EligibilityResult, UserProfile, LanguageCode, ApplicationTrackerItem } from '../types';
import { speakText, stopSpeaking } from '../utils/speech';
import { SUPPORTED_LANGUAGES } from '../utils/translations';

interface SchemeResultsProps {
  userProfile: UserProfile;
  eligibleSchemes: EligibilityResult[];
  ineligibleSchemes: EligibilityResult[];
  language: LanguageCode;
  onAddToTracker: (item: ApplicationTrackerItem) => void;
  onModifyProfile: () => void;
  onAskAiAboutScheme: (schemeName: string) => void;
}

export const SchemeResults: React.FC<SchemeResultsProps> = ({
  userProfile,
  eligibleSchemes,
  ineligibleSchemes,
  language,
  onAddToTracker,
  onModifyProfile,
  onAskAiAboutScheme,
}) => {
  const [expandedSchemeId, setExpandedSchemeId] = useState<string | null>(
    eligibleSchemes.length > 0 ? eligibleSchemes[0].scheme.id : null
  );
  const [showIneligible, setShowIneligible] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [addedTrackerIds, setAddedTrackerIds] = useState<string[]>([]);

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  const totalPossibleSubsidy = eligibleSchemes.reduce(
    (max, item) => Math.max(max, item.calculatedSubsidy || 0),
    0
  );

  const handleReadSummary = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    const bestScheme = eligibleSchemes[0];
    let message = '';
    if (bestScheme) {
      message = `Great news ${userProfile.name}! We found ${eligibleSchemes.length} schemes you qualify for. Your best match is ${bestScheme.scheme.name}. You can receive up to ${bestScheme.scheme.amountLabel} with zero property mortgage.`;
    } else {
      message = `Hello ${userProfile.name}. We checked the government guidelines. See the reasons below to know why other schemes were not matched.`;
    }

    setIsSpeaking(true);
    speakText(message, currentLangObj.speechLocale, () => {
      setIsSpeaking(false);
    });
  };

  const handleTrackScheme = (res: EligibilityResult) => {
    const newItem: ApplicationTrackerItem = {
      id: `app-${Date.now()}-${res.scheme.id}`,
      schemeId: res.scheme.id,
      schemeName: res.scheme.name,
      applicantName: userProfile.name,
      appliedDate: new Date().toLocaleDateString('en-GB'),
      requestedAmount: userProfile.investmentNeeded,
      currentStage: 'Document Preparation',
      stageProgress: 20,
      applicationRefNumber: `YS-${userProfile.state.substring(0, 2).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`,
      bankName: 'State Bank of India (Assigned Branch)',
      branch: `${userProfile.state} Local MSME Desk`,
      notes: `Qualified via YojanaSetu. Subsidy benefit: ₹${(res.calculatedSubsidy || 0).toLocaleString('en-IN')}.`,
      reminders: [
        {
          id: `rem-1-${Date.now()}`,
          task: 'Complete free Udyam registration at udyamregistration.gov.in',
          dueDate: 'Within 3 days',
          completed: false,
          priority: 'High',
        },
        {
          id: `rem-2-${Date.now()}`,
          task: 'Collect price estimate / quotation from machine seller',
          dueDate: 'Within 7 days',
          completed: false,
          priority: 'Medium',
        },
        {
          id: `rem-3-${Date.now()}`,
          task: `Submit application on ${res.scheme.portalName}`,
          dueDate: 'Within 14 days',
          completed: false,
          priority: 'High',
        },
      ],
    };

    onAddToTracker(newItem);
    setAddedTrackerIds((prev) => [...prev, res.scheme.id]);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      {/* Friendly Results Header Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
              <span>Eligibility Checked Successfully</span>
              <span aria-hidden="true">·</span>
              <span>{userProfile.category} Category</span>
              <span aria-hidden="true">·</span>
              <span>{userProfile.areaType} Area</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Good News, {userProfile.name}! You Qualify for {eligibleSchemes.length} Schemes
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1">
              For your <strong>{userProfile.tradeType || userProfile.businessType}</strong> business needing <strong className="text-white font-mono">₹{userProfile.investmentNeeded.toLocaleString('en-IN')}</strong>.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReadSummary}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                isSpeaking
                  ? 'bg-amber-600 text-white border-amber-600'
                  : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{isSpeaking ? 'Stop Audio' : 'Listen'}</span>
            </button>

            <button
              onClick={onModifyProfile}
              className="px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-800 border border-slate-700 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              Change Answers
            </button>
          </div>
        </div>

        {/* Free Cash Subsidy Highlight Bar */}
        {totalPossibleSubsidy > 0 && (
          <div className="mt-4 pt-3.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Government Free Cash Grant (Subsidy You Don't Pay Back):</span>
            </span>
            <span className="text-amber-400 font-mono font-extrabold text-sm sm:text-base tabular-nums">
              Up to ₹{totalPossibleSubsidy.toLocaleString('en-IN')}
            </span>
          </div>
        )}
      </div>

      {/* MATCHED SCHEMES LIST */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              Schemes You Qualify For ({eligibleSchemes.length})
            </h3>
          </div>
          <span className="text-xs text-slate-500">Highest matching first</span>
        </div>

        {eligibleSchemes.length === 0 ? (
          <div className="p-8 text-center bg-white border border-slate-200 rounded-xl">
            <p className="text-sm text-slate-600 mb-3">
              No schemes matched your exact combination. Check the reasons below to see what adjustments can be made.
            </p>
            <button
              onClick={onModifyProfile}
              className="text-xs font-bold text-amber-700 hover:underline cursor-pointer"
            >
              Adjust Amount or Details
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {eligibleSchemes.map((res, index) => {
              const scheme = res.scheme;
              const isExpanded = expandedSchemeId === scheme.id;
              const isAdded = addedTrackerIds.includes(scheme.id);

              return (
                <div
                  key={scheme.id}
                  className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs hover:border-slate-300 transition-colors"
                >
                  {/* Card Header */}
                  <div className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="font-semibold text-slate-700">{scheme.ministry.split('(')[0]}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-emerald-700 font-bold font-mono">{res.matchScore}% Match</span>
                      </div>

                      <h4 className="text-base font-bold text-slate-900">
                        {index + 1}. {scheme.name}
                        {scheme.nameInHindi && (
                          <span className="text-xs font-normal text-slate-500 ml-1.5">
                            ({scheme.nameInHindi})
                          </span>
                        )}
                      </h4>

                      <p className="text-xs text-slate-600 max-w-xl">
                        {scheme.tagline}
                      </p>
                    </div>

                    <div className="flex flex-col sm:items-end justify-center shrink-0 space-y-2">
                      <div className="text-left sm:text-right">
                        <span className="text-sm font-bold font-mono text-slate-900 block tabular-nums">
                          {scheme.amountLabel}
                        </span>
                        {res.calculatedSubsidyNote ? (
                          <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 block mt-0.5">
                            {res.calculatedSubsidyNote}
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-500">
                            Zero Property Mortgage Required
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleTrackScheme(res)}
                          disabled={isAdded}
                          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                            isAdded
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-slate-900 text-white hover:bg-slate-800'
                          }`}
                        >
                          {isAdded ? '✓ Added to Tracker' : '+ Track My Application'}
                        </button>

                        <button
                          onClick={() => setExpandedSchemeId(isExpanded ? null : scheme.id)}
                          className="px-2.5 py-1.5 text-xs text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <span>{isExpanded ? 'Less' : 'Details'}</span>
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Understandable Guide */}
                  {isExpanded && (
                    <div className="px-4 sm:px-5 pb-5 pt-2 border-t border-slate-100 bg-slate-50/50 space-y-4 text-xs">
                      {/* Why you qualify */}
                      <div>
                        <span className="font-bold text-slate-900 uppercase block mb-1">
                          Why This Fits You:
                        </span>
                        <ul className="space-y-1 text-slate-700">
                          {res.matchedReasons.map((reason, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <span className="text-emerald-600 font-bold">✓</span>
                              <span>{reason}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Documents Needed in Simple Colors */}
                      <div className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900 uppercase">
                            Documents Required ({res.heldDocuments.length} of {scheme.requiredDocuments.length} ready)
                          </span>
                          <span className="text-[11px] text-slate-500">
                            {res.missingDocuments.length === 0 ? '✓ All Documents Ready!' : `${res.missingDocuments.length} to collect`}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {scheme.requiredDocuments.map((doc) => {
                            const isHeld = res.heldDocuments.includes(doc);
                            return (
                              <div
                                key={doc}
                                className={`flex items-start gap-1.5 p-2 rounded-lg border ${
                                  isHeld
                                    ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950 font-medium'
                                    : 'bg-amber-50/60 border-amber-200 text-amber-950'
                                }`}
                              >
                                <span className={isHeld ? 'text-emerald-700 font-bold' : 'text-amber-700 font-bold'}>
                                  {isHeld ? '✓ You Have' : '⚠️ Need'}
                                </span>
                                <div>
                                  <span>{doc}</span>
                                  {!isHeld && (
                                    <span className="block text-[10px] text-amber-800 mt-0.5">
                                      Ask your local CSC kiosk or Tehsil center
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Simple 3-step application roadmap */}
                      <div>
                        <span className="font-bold text-slate-900 uppercase block mb-1.5">
                          How to Apply in 3 Easy Steps:
                        </span>
                        <ol className="space-y-1 text-slate-700 list-decimal pl-4">
                          {scheme.applicationSteps.map((stepStr, sIdx) => (
                            <li key={sIdx}>{stepStr}</li>
                          ))}
                        </ol>
                      </div>

                      {/* Action Links */}
                      <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200">
                        <div className="flex items-center gap-2">
                          <a
                            href={scheme.officialPortalUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold text-xs shadow-2xs"
                          >
                            <span>Go to Official {scheme.portalName}</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>

                          <button
                            onClick={() => onAskAiAboutScheme(scheme.name)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg font-medium text-xs cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                            <span>Ask Question About This Scheme</span>
                          </button>
                        </div>

                        <span className="text-[11px] text-slate-500">
                          Official Government Portal · Free to Apply
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* WHY OTHER SCHEMES DIDN'T MATCH (PLAIN & UNDERSTANDABLE) */}
      <div className="border border-slate-200 rounded-xl bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-amber-700" />
            <h3 className="text-sm sm:text-base font-bold text-slate-900">
              Why Other Schemes Were Not Recommended ({ineligibleSchemes.length})
            </h3>
          </div>
          <button
            onClick={() => setShowIneligible(!showIneligible)}
            className="text-xs font-semibold text-amber-800 hover:text-amber-900 cursor-pointer"
          >
            {showIneligible ? 'Hide Details' : 'Show Details'}
          </button>
        </div>

        <p className="text-xs text-slate-500 mb-3">
          To save your time, we only recommend schemes you truly qualify for. Here is why the others were not matched:
        </p>

        {showIneligible && (
          <div className="divide-y divide-slate-100">
            {ineligibleSchemes.map((res) => {
              const scheme = res.scheme;
              return (
                <div key={scheme.id} className="py-2.5 first:pt-0 last:pb-0 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-800">{scheme.name}</span>
                    <span className="text-[11px] text-slate-500">{scheme.amountLabel}</span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 space-y-0.5 text-slate-700">
                    {res.unmatchedReasons.map((reason, rIdx) => (
                      <p key={rIdx} className="flex items-start gap-1.5">
                        <span className="text-amber-700 font-bold shrink-0">•</span>
                        <span>{reason}</span>
                      </p>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
