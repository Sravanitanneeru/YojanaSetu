import React, { useState } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  Square, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle, 
  Sparkles, 
  HelpCircle,
  Coins,
  Check
} from 'lucide-react';
import { UserProfile, LanguageCode, SocialCategory, Gender, AreaType, BusinessType, EducationLevel } from '../types';
import { speakText, stopSpeaking, createSpeechRecognizer, isSpeechRecognitionSupported } from '../utils/speech';
import { SUPPORTED_LANGUAGES, UI_TRANSLATIONS } from '../utils/translations';
import { SAMPLE_PROFILES } from '../data/sampleProfiles';

interface ConversationalAssessmentProps {
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  language: LanguageCode;
  onEvaluate: () => void;
  onSelectSampleProfile: (profile: UserProfile) => void;
}

const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
  'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Delhi', 'Jammu & Kashmir', 'Ladakh'
];

const COMMON_DOCUMENTS = [
  'Aadhaar Card',
  'Bank Passbook (Aadhaar linked)',
  'Mobile linked with Aadhaar',
  'PAN Card',
  'Caste / Community Certificate (for SC/ST/OBC/Minority subsidy)',
  'Income Certificate (Annual income < ₹3 Lakh/year)',
  'Artisan Trade Self-Declaration / Gram Panchayat Verification',
  'Rural Area Certificate (issued by Gram Panchayat for 35% rural subsidy)',
  'Proof of Business (Udyam Registration / Shop & Establishment license)',
  'Detailed Project Report (DPR / Business Plan)',
  'Educational Qualification Certificate (8th pass certificate if project > ₹10L)'
];

export const ConversationalAssessment: React.FC<ConversationalAssessmentProps> = ({
  userProfile,
  setUserProfile,
  language,
  onEvaluate,
  onSelectSampleProfile,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceNotice, setVoiceNotice] = useState<string>('');

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];
  const t = UI_TRANSLATIONS[language] || UI_TRANSLATIONS.en;

  // Toggle voice recognition
  const toggleVoiceInput = () => {
    if (!isSpeechRecognitionSupported()) {
      setVoiceNotice('Microphone not supported in this browser. Please click the options.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      setVoiceNotice('');
      return;
    }

    setIsListening(true);
    setVoiceNotice('Listening to your voice... Speak your name, trade, or investment amount.');

    const recognizer = createSpeechRecognizer(
      currentLangObj.speechLocale,
      (transcript) => {
        setVoiceNotice(`Heard: "${transcript}"`);
        const lower = transcript.toLowerCase();
        if (step === 1) {
          if (lower.includes('female') || lower.includes('महिला') || lower.includes('woman')) {
            setUserProfile((prev) => ({ ...prev, gender: 'Female' }));
          } else if (lower.includes('male') || lower.includes('पुरुष') || lower.includes('man')) {
            setUserProfile((prev) => ({ ...prev, gender: 'Male' }));
          }

          if (lower.includes('sc') || lower.includes('अनुसूचित')) {
            setUserProfile((prev) => ({ ...prev, category: 'SC' }));
          } else if (lower.includes('st') || lower.includes('जनजाति')) {
            setUserProfile((prev) => ({ ...prev, category: 'ST' }));
          } else if (lower.includes('obc') || lower.includes('पिछड़ा')) {
            setUserProfile((prev) => ({ ...prev, category: 'OBC' }));
          }
        }
      },
      (err) => {
        setIsListening(false);
        setVoiceNotice(`Microphone error: ${err}`);
      },
      () => {
        setIsListening(false);
      }
    );

    if (recognizer) {
      try {
        recognizer.start();
      } catch (e) {
        setIsListening(false);
      }
    }
  };

  // Read current question aloud
  const handleReadQuestion = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    let textToSpeak = '';
    if (step === 1) {
      textToSpeak = language === 'hi'
        ? 'कृपया अपना नाम, आयु, लिंग, सामाजिक वर्ग, और राज्य चुनें।'
        : 'Please specify your full name, age, gender, social category, and home state.';
    } else if (step === 2) {
      textToSpeak = language === 'hi'
        ? 'आप किस प्रकार का उद्यम या पारंपरिक शिल्प शुरू अथवा बढ़ाना चाहते हैं?'
        : 'What category of enterprise or traditional artisan craft are you planning?';
    } else {
      textToSpeak = language === 'hi'
        ? 'आपको कुल कितने ऋण या पूंजी की आवश्यकता है? और आपके पास कौन से दस्तावेज हैं?'
        : 'How much loan or capital do you need? And which documents do you already have?';
    }

    setIsSpeaking(true);
    speakText(textToSpeak, currentLangObj.speechLocale, () => {
      setIsSpeaking(false);
    });
  };

  const handleDocumentToggle = (doc: string) => {
    setUserProfile((prev) => {
      const exists = prev.documentsHeld.includes(doc);
      if (exists) {
        return {
          ...prev,
          documentsHeld: prev.documentsHeld.filter((d) => d !== doc),
        };
      } else {
        return {
          ...prev,
          documentsHeld: [...prev.documentsHeld, doc],
        };
      }
    });
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* 1-Click Example Personas */}
      <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-3.5 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
          <span className="text-xs font-bold text-amber-900">
            Quick Test: Click Any Medium-Range Example
          </span>
          <span className="text-[11px] text-amber-700">Pre-fills real entrepreneur data</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_PROFILES.map((p) => (
            <button
              key={p.id}
              onClick={() => onSelectSampleProfile(p)}
              className="text-xs px-2.5 py-1.5 bg-white border border-amber-300 hover:bg-amber-100 rounded-md font-medium text-slate-800 transition-colors cursor-pointer"
            >
              <span className="font-semibold">{p.name.split(' ')[0]}</span>
              <span className="text-slate-500"> ({p.tradeType || p.businessType.split('/')[0]} · ₹{(p.investmentNeeded / 100000).toFixed(1)}L)</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Questionnaire Box */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        {/* Step Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-800 mb-0.5">
              <span>Step {step} of 3</span>
              <span aria-hidden="true">·</span>
              <span>
                {step === 1 ? 'About You' : step === 2 ? 'Your Business' : 'Money & Documents'}
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              {step === 1 && 'Step 1: Tell Us About Yourself'}
              {step === 2 && 'Step 2: What Business or Craft Do You Do?'}
              {step === 3 && 'Step 3: How Much Money Do You Need?'}
            </h3>
          </div>

          {/* Voice Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReadQuestion}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                isSpeaking
                  ? 'bg-amber-600 text-white border-amber-600'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {isSpeaking ? <Square className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{isSpeaking ? 'Stop Audio' : 'Listen'}</span>
            </button>

            <button
              onClick={toggleVoiceInput}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                isListening
                  ? 'bg-red-600 text-white border-red-600 animate-pulse'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              <span>{isListening ? 'Listening...' : 'Speak'}</span>
            </button>
          </div>
        </div>

        {voiceNotice && (
          <div className="px-5 py-2 bg-blue-50 border-b border-blue-100 text-xs text-blue-900 font-medium">
            {voiceNotice}
          </div>
        )}

        <div className="p-5 sm:p-6">
          {/* STEP 1: Personal Profile */}
          {step === 1 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={userProfile.name}
                    onChange={(e) => setUserProfile({ ...userProfile, name: e.target.value })}
                    placeholder="e.g. Sunita Devi"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Your Age (Years)
                  </label>
                  <input
                    type="number"
                    min={18}
                    max={80}
                    value={userProfile.age}
                    onChange={(e) => setUserProfile({ ...userProfile, age: parseInt(e.target.value, 10) || 18 })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white font-mono"
                  />
                  <span className="text-[11px] text-slate-500 mt-1 block">Government schemes require applicant to be 18 or older.</span>
                </div>
              </div>

              {/* Gender */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  Gender
                </label>
                <div className="grid grid-cols-3 gap-2.5">
                  {(['Female', 'Male', 'Other'] as Gender[]).map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setUserProfile({ ...userProfile, gender: g })}
                      className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                        userProfile.gender === g
                          ? 'bg-amber-50 border-amber-600 text-amber-900'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {g} {g === 'Female' && '👩'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Social Category */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase">
                    Your Social Category (Caste / Community)
                  </label>
                  <span className="text-[11px] text-amber-800 font-medium">SC, ST & OBC qualify for up to 35% subsidy</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(['SC', 'ST', 'OBC', 'Minority', 'General', 'EWS'] as SocialCategory[]).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setUserProfile({ ...userProfile, category: cat })}
                      className={`p-2.5 text-left rounded-lg border text-xs transition-colors cursor-pointer ${
                        userProfile.category === cat
                          ? 'bg-amber-50 border-amber-600 text-amber-900 font-bold'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div>{cat}</div>
                      <div className="text-[11px] text-slate-500 font-normal">
                        {cat === 'SC' && 'Scheduled Caste'}
                        {cat === 'ST' && 'Scheduled Tribe'}
                        {cat === 'OBC' && 'Backward Class'}
                        {cat === 'Minority' && 'Minority Group'}
                        {cat === 'General' && 'General'}
                        {cat === 'EWS' && 'EWS'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* State & Area */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Your State
                  </label>
                  <select
                    value={userProfile.state}
                    onChange={(e) => setUserProfile({ ...userProfile, state: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white"
                  >
                    {INDIAN_STATES.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Where is Your Business Located?
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['Rural', 'Urban'] as AreaType[]).map((area) => (
                      <button
                        key={area}
                        type="button"
                        onClick={() => setUserProfile({ ...userProfile, areaType: area })}
                        className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                          userProfile.areaType === area
                            ? 'bg-amber-50 border-amber-600 text-amber-900'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {area === 'Rural' ? 'Village / Rural (35% Subsidy)' : 'City / Urban (25% Subsidy)'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Business & Craft */}
          {step === 2 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-2">
                  Select Your Business Type
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {(
                    [
                      'Artisan / Traditional Craft',
                      'Textiles & Handloom',
                      'Food Processing',
                      'Service / Retail',
                      'Manufacturing',
                      'Agriculture & Allied'
                    ] as BusinessType[]
                  ).map((bType) => (
                    <button
                      key={bType}
                      type="button"
                      onClick={() => setUserProfile({ ...userProfile, businessType: bType })}
                      className={`p-3 text-left rounded-lg border text-xs transition-colors cursor-pointer ${
                        userProfile.businessType === bType
                          ? 'bg-amber-50 border-amber-600 text-amber-900 font-bold'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div className="font-bold">{bType}</div>
                      <div className="text-[11px] text-slate-500 font-normal mt-0.5">
                        {bType === 'Artisan / Traditional Craft' && 'Potter, Weaver, Carpenter, Blacksmith, Sculptor'}
                        {bType === 'Textiles & Handloom' && 'Tailoring boutique, Garment making, Handloom weaving'}
                        {bType === 'Food Processing' && 'Spices, Pickles, Makhana, Flour mill, Bakery, Dairy'}
                        {bType === 'Service / Retail' && 'Small shop, Grocery, Repair center, Printing, Beauty parlour'}
                        {bType === 'Manufacturing' && 'Workshop, Fabrication, Light engineering, Packaging'}
                        {bType === 'Agriculture & Allied' && 'Mushroom cultivation, Poultry, Dairy cattle, Goat farming'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* If Artisan or Textiles */}
              {(userProfile.businessType === 'Artisan / Traditional Craft' || userProfile.businessType === 'Textiles & Handloom') && (
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl">
                  <label className="block text-xs font-bold text-amber-900 uppercase mb-1">
                    Your Specific Artisan Trade (PM Vishwakarma Eligible)
                  </label>
                  <select
                    value={userProfile.tradeType || 'Potter'}
                    onChange={(e) => setUserProfile({ ...userProfile, tradeType: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-amber-300 bg-white text-slate-900"
                  >
                    <option value="Potter">Potter (Kumhaar - मिट्टी के बर्तन)</option>
                    <option value="Weaver">Weaver (Bunkar - हथकरघा / बुनाई)</option>
                    <option value="Carpenter">Carpenter (Suthar - बढ़ई / लकड़ी काम)</option>
                    <option value="Blacksmith">Blacksmith (Lohar - लोहार)</option>
                    <option value="Tailor">Tailor (Darzi - सिलाई / दर्जी)</option>
                    <option value="Cobbler">Cobbler / Footwear Artisan (मोची)</option>
                    <option value="Sculptor">Sculptor / Stone Carver (मूर्तिकार)</option>
                    <option value="Barber">Barber (Naai - नाई)</option>
                    <option value="Washerman">Washerman (Dhobi - धोबी)</option>
                    <option value="Other">Other Craft Trade</option>
                  </select>
                  <span className="text-[11px] text-amber-800 mt-1 block">
                    Vishwakarma gives ₹15,000 free tool voucher + ₹3 Lakh loan at 5% interest.
                  </span>
                </div>
              )}

              {/* Education Level */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  Your Education Level
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {(['Below 8th', '8th Pass', '10th Pass', '12th Pass', 'Graduate & Above'] as EducationLevel[]).map((edu) => (
                    <button
                      key={edu}
                      type="button"
                      onClick={() => setUserProfile({ ...userProfile, education: edu })}
                      className={`py-2 px-2 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                        userProfile.education === edu
                          ? 'bg-amber-50 border-amber-600 text-amber-900'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {edu}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Money Needed & Documents */}
          {step === 3 && (
            <div className="space-y-5">
              {/* Money needed with Medium-Range Presets */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase">
                    Loan / Capital Amount Needed
                  </label>
                  <span className="text-base font-extrabold font-mono text-amber-700 tabular-nums">
                    ₹{userProfile.investmentNeeded.toLocaleString('en-IN')}
                  </span>
                </div>

                <input
                  type="range"
                  min={50000}
                  max={2500000}
                  step={25000}
                  value={userProfile.investmentNeeded}
                  onChange={(e) =>
                    setUserProfile({ ...userProfile, investmentNeeded: parseInt(e.target.value, 10) })
                  }
                  className="w-full accent-amber-600 cursor-pointer"
                />

                {/* Popular Medium Range Presets */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-2.5">
                  {[
                    { amt: 50000, label: '₹50K (Micro Mudra)' },
                    { amt: 100000, label: '₹1 Lakh (Tool Kit)' },
                    { amt: 250000, label: '₹2.5L (Workshop)' },
                    { amt: 500000, label: '₹5L (Small Unit)' },
                    { amt: 1000000, label: '₹10L (Commercial)' },
                  ].map((preset) => (
                    <button
                      key={preset.amt}
                      type="button"
                      onClick={() => setUserProfile({ ...userProfile, investmentNeeded: preset.amt })}
                      className={`py-1.5 px-2 text-xs rounded border transition-colors cursor-pointer font-medium ${
                        userProfile.investmentNeeded === preset.amt
                          ? 'bg-amber-600 text-white border-amber-600 font-bold'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Documents Held */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase">
                    Tick Which Documents You Already Have
                  </label>
                  <span className="text-xs text-slate-500 font-mono">
                    {userProfile.documentsHeld.length} / {COMMON_DOCUMENTS.length} ready
                  </span>
                </div>
                <p className="text-xs text-slate-500 mb-2.5">
                  Don't worry if you miss some — we show you how to get missing documents easily.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto p-1 border border-slate-200 rounded-xl">
                  {COMMON_DOCUMENTS.map((doc) => {
                    const isChecked = userProfile.documentsHeld.includes(doc);
                    return (
                      <button
                        key={doc}
                        type="button"
                        onClick={() => handleDocumentToggle(doc)}
                        className={`flex items-start gap-2 p-2 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                          isChecked
                            ? 'bg-emerald-50/60 border-emerald-500 text-slate-900 font-medium'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded mt-0.5 shrink-0 flex items-center justify-center border ${
                            isChecked
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 bg-white'
                          }`}
                        >
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                        <span className="text-[12px] leading-snug">{doc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          {step > 1 ? (
            <button
              onClick={() => setStep((prev) => (prev - 1) as any)}
              className="inline-flex items-center gap-1 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {step < 3 ? (
            <button
              onClick={() => setStep((prev) => (prev + 1) as any)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <span>Next Step</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={onEvaluate}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-200" />
              <span>See My Schemes & Subsidies</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
