import React, { useState } from 'react';
import { 
  Search, 
  ExternalLink, 
  Sparkles, 
  ShieldCheck, 
  Award, 
  Filter, 
  ChevronRight,
  Landmark,
  Coins
} from 'lucide-react';
import { Scheme, SchemeCategory } from '../types';

interface SchemeDirectoryProps {
  schemes: Scheme[];
  onSelectSchemeForAssessment: (scheme: Scheme) => void;
  onAskAiAboutScheme: (schemeName: string) => void;
}

const CATEGORIES: ('All' | SchemeCategory)[] = [
  'All',
  'Artisans & Craftsmen',
  'Subsidies & Grants',
  'Loans & Credit',
  'Women Entrepreneurs',
  'SC/ST & Backward Classes',
  'Food & Agriculture',
  'Skill Training',
];

export const SchemeDirectory: React.FC<SchemeDirectoryProps> = ({
  schemes,
  onSelectSchemeForAssessment,
  onAskAiAboutScheme,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'All' | SchemeCategory>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [amountFilter, setAmountFilter] = useState<'all' | 'under1L' | '1Lto5L' | '5Lto25L' | 'above25L'>('all');
  const [activeModalScheme, setActiveModalScheme] = useState<Scheme | null>(null);

  const filteredSchemes = schemes.filter((s) => {
    // Category match
    if (selectedCategory !== 'All' && s.category !== selectedCategory) {
      return false;
    }

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        s.name.toLowerCase().includes(q) ||
        (s.nameInHindi && s.nameInHindi.toLowerCase().includes(q)) ||
        s.ministry.toLowerCase().includes(q) ||
        s.tagline.toLowerCase().includes(q) ||
        s.briefDescription.toLowerCase().includes(q);
      if (!match) return false;
    }

    // Amount match
    if (amountFilter === 'under1L' && s.maxAmount > 100000) return false;
    if (amountFilter === '1Lto5L' && (s.maxAmount <= 100000 || s.maxAmount > 500000)) return false;
    if (amountFilter === '5Lto25L' && (s.maxAmount <= 500000 || s.maxAmount > 2500000)) return false;
    if (amountFilter === 'above25L' && s.maxAmount <= 2500000) return false;

    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Catalog Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-amber-800 mb-1.5">
          <span>Official Knowledge Base</span>
          <span aria-hidden="true">·</span>
          <span>Central Ministries & State Departments</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Government Schemes Knowledge Catalog
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          Search and examine official guidelines, financial ceilings, capital subsidies, and document rules across 12+ schemes.
        </p>
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs mb-8 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by scheme name, ministry, or trade (e.g. Vishwakarma, PMEGP, Potter)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
            />
          </div>

          {/* Amount Ceiling Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600 uppercase whitespace-nowrap">Amount:</span>
            <select
              value={amountFilter}
              onChange={(e) => setAmountFilter(e.target.value as any)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="all">All Amounts</option>
              <option value="under1L">Under ₹1 Lakh</option>
              <option value="1Lto5L">₹1L - ₹5 Lakhs</option>
              <option value="5Lto25L">₹5L - ₹25 Lakhs</option>
              <option value="above25L">₹25L - ₹1 Crore+</option>
            </select>
          </div>
        </div>

        {/* Category Filter Tabs (Single-line interactive buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? 'bg-amber-600 text-white font-semibold shadow-2xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Schemes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSchemes.map((scheme) => (
          <div
            key={scheme.id}
            className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs hover:border-amber-400 hover:shadow-sm transition-all flex flex-col justify-between"
          >
            <div>
              {/* Unboxed Metadata Line */}
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span className="font-semibold text-slate-700 truncate max-w-[200px]">{scheme.ministry.split('(')[0]}</span>
                <span className="font-mono text-amber-800 font-bold">{scheme.code}</span>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug mb-1">
                {scheme.name}
              </h3>
              {scheme.nameInHindi && (
                <p className="text-xs text-slate-500 mb-2.5">
                  {scheme.nameInHindi}
                </p>
              )}

              <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-4">
                {scheme.tagline}
              </p>

              {/* Financial Metrics Strip */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1 text-xs mb-4">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Max Financial Scale:</span>
                  <span className="font-bold font-mono text-slate-900 tabular-nums">
                    {scheme.amountLabel}
                  </span>
                </div>
                {scheme.subsidyPercentage && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Capital Subsidy:</span>
                    <span className="font-bold text-amber-700">
                      Up to {scheme.subsidyPercentage}%
                    </span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Collateral Security:</span>
                  <span className="font-semibold text-emerald-700">
                    {scheme.collateralRequired ? 'Mortgage Required' : 'Zero Collateral Required'}
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
              <button
                onClick={() => setActiveModalScheme(scheme)}
                className="text-amber-700 hover:text-amber-800 font-semibold cursor-pointer"
              >
                View Full Guidelines →
              </button>

              <button
                onClick={() => onAskAiAboutScheme(scheme.name)}
                className="p-1.5 text-slate-500 hover:text-amber-700 transition-colors cursor-pointer rounded hover:bg-slate-100"
                title={`Ask AI Advisor about ${scheme.name}`}
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredSchemes.length === 0 && (
        <div className="text-center py-12 bg-white border border-slate-200 rounded-xl">
          <p className="text-sm text-slate-500">No schemes found matching your search or filters.</p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setAmountFilter('all');
            }}
            className="text-xs font-bold text-amber-700 hover:underline mt-2 cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Scheme Detail Modal */}
      {activeModalScheme && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 shadow-xl border border-slate-200">
            <div className="flex items-start justify-between pb-4 border-b border-slate-200">
              <div>
                <span className="text-xs font-semibold text-amber-800">{activeModalScheme.ministry}</span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">
                  {activeModalScheme.name}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalScheme(null)}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs text-slate-700">
              <div>
                <h4 className="font-bold text-slate-900 uppercase mb-1">Official Description</h4>
                <p className="leading-relaxed">{activeModalScheme.briefDescription}</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 uppercase mb-1">Eligibility Criteria</h4>
                <p className="leading-relaxed">{activeModalScheme.eligibilityExplanation}</p>
              </div>

              {activeModalScheme.subsidyNote && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <span className="font-bold text-amber-900 block mb-0.5">Subsidy & Financial Concession</span>
                  <p className="text-amber-950">{activeModalScheme.subsidyNote}</p>
                </div>
              )}

              <div>
                <h4 className="font-bold text-slate-900 uppercase mb-1">Mandatory Documents</h4>
                <ul className="list-disc pl-4 space-y-1">
                  {activeModalScheme.requiredDocuments.map((doc, idx) => (
                    <li key={idx}>{doc}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 uppercase mb-1">Application Steps</h4>
                <ol className="list-decimal pl-4 space-y-1">
                  {activeModalScheme.applicationSteps.map((step, idx) => (
                    <li key={idx}>{step}</li>
                  ))}
                </ol>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
              <a
                href={activeModalScheme.officialPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold text-xs shadow-2xs"
              >
                <span>Visit {activeModalScheme.portalName}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={() => {
                  onSelectSchemeForAssessment(activeModalScheme);
                  setActiveModalScheme(null);
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold text-xs cursor-pointer"
              >
                Check My Eligibility
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
