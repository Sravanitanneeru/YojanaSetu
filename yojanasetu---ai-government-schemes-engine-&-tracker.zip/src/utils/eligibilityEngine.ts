import { UserProfile, Scheme, EligibilityResult, EducationLevel } from '../types';

const EDUCATION_RANK: Record<EducationLevel, number> = {
  'Below 8th': 1,
  '8th Pass': 2,
  '10th Pass': 3,
  '12th Pass': 4,
  'Graduate & Above': 5,
};

export function evaluateSchemeEligibility(profile: UserProfile, scheme: Scheme): EligibilityResult {
  const matchedReasons: string[] = [];
  const unmatchedReasons: string[] = [];
  let isEligible = true;

  const rules = scheme.rules;

  // 1. Age verification
  if (rules.minAge && profile.age < rules.minAge) {
    isEligible = false;
    unmatchedReasons.push(`Applicant age (${profile.age}) is below the required minimum age of ${rules.minAge} years.`);
  } else if (rules.maxAge && profile.age > rules.maxAge) {
    isEligible = false;
    unmatchedReasons.push(`Applicant age (${profile.age}) exceeds the upper limit of ${rules.maxAge} years.`);
  } else {
    matchedReasons.push(`Age eligibility fulfilled (${profile.age} years within allowed bracket).`);
  }

  // 2. Gender specific rules
  if (rules.allowedGenders && !rules.allowedGenders.includes(profile.gender)) {
    isEligible = false;
    unmatchedReasons.push(`This scheme is exclusively reserved for ${rules.allowedGenders.join(', ')} entrepreneurs.`);
  }

  // 3. Stand-Up India special dual condition: Must be Woman OR SC/ST
  if (scheme.id === 'stand-up-india') {
    const isWoman = profile.gender === 'Female';
    const isScOrSt = profile.category === 'SC' || profile.category === 'ST';
    if (!isWoman && !isScOrSt) {
      isEligible = false;
      unmatchedReasons.push(`Stand-Up India is legally restricted to Women entrepreneurs (all castes) or SC/ST male entrepreneurs. General/OBC male applicants are not eligible.`);
    } else {
      matchedReasons.push(
        isWoman
          ? `Eligible under Woman Entrepreneur quota across all communities.`
          : `Eligible under ${profile.category} category affirmative credit quota.`
      );
    }
  }

  // 4. Social Category rules (e.g. NSFDC for SC only)
  if (rules.allowedCategories && !rules.allowedCategories.includes(profile.category)) {
    isEligible = false;
    unmatchedReasons.push(`Requires applicant to belong to ${rules.allowedCategories.join(' / ')} category (your profile is ${profile.category}).`);
  } else if (rules.allowedCategories && rules.allowedCategories.length < 6) {
    matchedReasons.push(`Social category requirement met (${profile.category} is an eligible beneficiary group).`);
  }

  // 5. Business Type check
  if (rules.allowedBusinessTypes && !rules.allowedBusinessTypes.includes(profile.businessType)) {
    isEligible = false;
    unmatchedReasons.push(`Your enterprise type (${profile.businessType}) is outside the scope of this scheme, which covers: ${rules.allowedBusinessTypes.join(', ')}.`);
  } else if (rules.allowedBusinessTypes) {
    matchedReasons.push(`Enterprise domain (${profile.businessType}) is covered under the scheme guidelines.`);
  }

  // 6. Artisan Trade requirement
  if (rules.requiresArtisanTrade) {
    const isArtisanType = profile.businessType === 'Artisan / Traditional Craft' || profile.businessType === 'Textiles & Handloom';
    if (!isArtisanType) {
      isEligible = false;
      unmatchedReasons.push(`Requires applicant to be a traditional craftsperson, artisan, or weaver using hand tools.`);
    } else {
      matchedReasons.push(`Traditional artisan craft criterion fulfilled (${profile.tradeType || 'Artisan'}).`);
    }
  }

  // 7. Investment bounds
  if (rules.minInvestment && profile.investmentNeeded < rules.minInvestment) {
    isEligible = false;
    unmatchedReasons.push(
      `Your requested capital (₹${profile.investmentNeeded.toLocaleString('en-IN')}) is below the scheme minimum threshold of ₹${rules.minInvestment.toLocaleString('en-IN')}.`
    );
  }

  if (rules.maxInvestment && profile.investmentNeeded > rules.maxInvestment) {
    isEligible = false;
    unmatchedReasons.push(
      `Your requested capital (₹${profile.investmentNeeded.toLocaleString('en-IN')}) exceeds this scheme's upper financing limit of ₹${rules.maxInvestment.toLocaleString('en-IN')}.`
    );
  }

  if (
    (!rules.minInvestment || profile.investmentNeeded >= rules.minInvestment) &&
    (!rules.maxInvestment || profile.investmentNeeded <= rules.maxInvestment)
  ) {
    matchedReasons.push(`Capital requirement (₹${profile.investmentNeeded.toLocaleString('en-IN')}) is within the scheme financial bandwidth.`);
  }

  // 8. Education level check for PMEGP (KVIC rule: >10L Mfg or >5L Service requires 8th pass)
  if (scheme.id === 'pmegp') {
    const isHighValue = 
      (profile.businessType === 'Manufacturing' && profile.investmentNeeded > 1000000) ||
      (profile.businessType === 'Service / Retail' && profile.investmentNeeded > 500000);

    if (isHighValue && EDUCATION_RANK[profile.education] < EDUCATION_RANK['8th Pass']) {
      isEligible = false;
      unmatchedReasons.push(
        `Under KVIC guidelines, projects above ₹10 Lakhs (Manufacturing) or ₹5 Lakhs (Service) require minimum 8th class pass educational qualification.`
      );
    } else if (isHighValue) {
      matchedReasons.push(`Mandatory educational requirement (8th pass or above) satisfied for project above ₹10 Lakhs.`);
    }
  }

  // 9. Document Analysis
  const normalizedHeld = profile.documentsHeld.map((d) => d.toLowerCase().trim());
  const missingDocuments: string[] = [];
  const heldDocuments: string[] = [];

  scheme.requiredDocuments.forEach((doc) => {
    const docLower = doc.toLowerCase();
    const isHeld = normalizedHeld.some(
      (held) =>
        held.includes(docLower) ||
        docLower.includes(held) ||
        (docLower.includes('aadhaar') && held.includes('aadhaar')) ||
        (docLower.includes('pan') && held.includes('pan')) ||
        (docLower.includes('passbook') && held.includes('passbook')) ||
        (docLower.includes('caste') && held.includes('caste')) ||
        (docLower.includes('dpr') && held.includes('dpr')) ||
        (docLower.includes('udyam') && held.includes('udyam'))
    );

    if (isHeld) {
      heldDocuments.push(doc);
    } else {
      missingDocuments.push(doc);
    }
  });

  // Calculate Benefit / Subsidy Value
  let calculatedSubsidy = 0;
  let calculatedSubsidyNote = '';

  const isSpecialCategory =
    profile.category === 'SC' ||
    profile.category === 'ST' ||
    profile.category === 'OBC' ||
    profile.category === 'Minority' ||
    profile.gender === 'Female' ||
    profile.differentlyAbled;

  if (scheme.id === 'pmegp') {
    const rate = isSpecialCategory
      ? profile.areaType === 'Rural' ? 35 : 25
      : profile.areaType === 'Rural' ? 25 : 15;
    
    calculatedSubsidy = Math.round(profile.investmentNeeded * (rate / 100));
    calculatedSubsidyNote = `Estimated ${rate}% capital subsidy = ₹${calculatedSubsidy.toLocaleString('en-IN')} (Non-refundable Government Margin Money grant)`;
  } else if (scheme.id === 'pmfme') {
    calculatedSubsidy = Math.min(1000000, Math.round(profile.investmentNeeded * 0.35));
    calculatedSubsidyNote = `35% Capital Subsidy = ₹${calculatedSubsidy.toLocaleString('en-IN')} (Credited to loan account)`;
  } else if (scheme.id === 'pm-vishwakarma') {
    calculatedSubsidy = 15000;
    calculatedSubsidyNote = `₹15,000 Digital Toolkit Voucher + 8% Interest Subvention (Net borrowing rate only 5%)`;
  } else if (scheme.id === 'samarth-textiles') {
    calculatedSubsidy = 35000;
    calculatedSubsidyNote = `100% Free certified skill training + daily wage compensation allowance`;
  } else if (scheme.subsidyPercentage) {
    calculatedSubsidy = Math.round(profile.investmentNeeded * (scheme.subsidyPercentage / 100));
    calculatedSubsidyNote = `${scheme.subsidyPercentage}% benefit / subvention equivalent`;
  }

  // Calculate Match Score
  let matchScore = 0;
  if (isEligible) {
    matchScore = 75; // base passed score
    // Document completeness factor (+15 max)
    if (scheme.requiredDocuments.length > 0) {
      const docRatio = heldDocuments.length / scheme.requiredDocuments.length;
      matchScore += Math.round(docRatio * 15);
    }
    // High demographic affinity (+10)
    if (isSpecialCategory && (scheme.category === 'Women Entrepreneurs' || scheme.category === 'SC/ST & Backward Classes' || scheme.id === 'pm-vishwakarma')) {
      matchScore += 10;
    }
    matchScore = Math.min(99, Math.max(70, matchScore));
  } else {
    // Partial score for transparency (how close they are)
    const passedChecks = matchedReasons.length;
    const totalChecks = matchedReasons.length + unmatchedReasons.length;
    matchScore = Math.round((passedChecks / Math.max(1, totalChecks)) * 45);
  }

  return {
    scheme,
    isEligible,
    matchScore,
    matchedReasons,
    unmatchedReasons,
    calculatedSubsidy,
    calculatedSubsidyNote,
    missingDocuments,
    heldDocuments,
  };
}

export function rankAndFilterSchemes(profile: UserProfile, schemes: Scheme[]): {
  eligibleSchemes: EligibilityResult[];
  ineligibleSchemes: EligibilityResult[];
} {
  const allEvaluations = schemes.map((s) => evaluateSchemeEligibility(profile, s));

  const eligibleSchemes = allEvaluations
    .filter((res) => res.isEligible)
    .sort((a, b) => b.matchScore - a.matchScore);

  const ineligibleSchemes = allEvaluations
    .filter((res) => !res.isEligible)
    .sort((a, b) => b.matchScore - a.matchScore);

  return {
    eligibleSchemes,
    ineligibleSchemes,
  };
}
